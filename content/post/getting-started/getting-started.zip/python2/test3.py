#xiaorui.cc
import threading
try:
    from synchronize import make_synchronized
except ImportError:
    def make_synchronized(func):
        import threading
        func.__lock__ = threading.Lock()

        def synced_func(*args, **kws):
            with func.__lock__:
                return func(*args, **kws)

        return synced_func

class Singleton(object):
    _instances = {}

    @make_synchronized
    def __new__(class_, *args, **kwargs):
        if class_ not in class_._instances:
            with threading.Lock():
                if class_ not in class_._instances:
                    class_._instances[class_] = super(Singleton, class_).__new__(class_)
        return class_._instances[class_]

    def __init__(self):
        self.blog = "xiaorui.cc"
        self.flag = True

    def go(self):
        pass


def worker(sequence):
    # print os.getpid()
    e = Singleton()
    print(e is e1)
    print id(e), e.blog
    e.go()

def test():
    e1 = Singleton()
    e2 = Singleton()
    e1.blog = 123
    e1.flag = False
    print e1.blog # 123
    print e2.blog # 123
    print id(e1)
    print id(e2)

if __name__ == "__main__":
    test()

    task = []
    for one in range(5):
        t = threading.Thread(target=worker)
        task.append(t)

    for one in task:
        one.start()

    for one in task:
        one.join()
    # import os
    # from multiprocessing import Pool
    # p = Pool(4)
    # for _ in range(4):
    #     p.apply(worker, [_])
    # p.close()
    # p.join()
