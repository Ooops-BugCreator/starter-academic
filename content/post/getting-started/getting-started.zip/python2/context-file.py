class File(object):
    def __init__(self, path):
        self.path = path

    def __enter__(self):
        print 'enter'
        self.f = open(self.path, 'r')
        return self.f

    def __exit__(self, *args, **kwargs):
        print 'exit'
        self.f.close()


def operate_file():
    with File('/Users/dickr/Downloads/test.txt') as f:
        print f.read()

operate_file()