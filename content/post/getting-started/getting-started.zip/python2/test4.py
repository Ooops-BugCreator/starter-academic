#xiaorui.cc
import threading
try:
    from synchronize import make_synchronized
except ImportError:
    def make_synchronized(func):
        import threading
        func.__lock__ = threading.Lock()

        def synced_func(*args, **kws):
            with func.__lock__:
                return func(*args, **kws)

        return synced_func

class Singleton(object):
    _instances = {}

    # @make_synchronized
    def __new__(class_, *args, **kwargs):
        if class_ not in class_._instances:
            with threading.Lock():
                if class_ not in class_._instances:
                    class_._instances[class_] = super(Singleton, class_).__new__(class_)
        return class_._instances[class_]

    def __init__(self):
        self.blog = "xiaorui.cc"

def worker():
    e = Singleton()
    print e.blog

if __name__ == "__main__":
    e1 = Singleton()
    e1.blog = 123
    t = threading.Thread(target=worker)
    t.start()
    t.join()

