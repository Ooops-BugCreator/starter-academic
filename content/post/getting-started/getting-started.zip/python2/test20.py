#!/usr/bin/env python
# -*- coding:utf-8 -*-
import smtplib

Server = "smtp.163.com"  # 163邮箱的SMTP服务器地址
Subject = "Test email from Python"  # 邮件主题
To = "1782463637@qq.com"  # 收件人
From = "18910746927@163.com"  # 发件人
Text = "This is the email send by xpleaf, from xpleaf@163.com!"  # 邮件内容
Body = '\r\n'.join(("From: %s" % From,
                    "To: %s" % To,
                    "Subject: %s" % Subject,
                    "",
                    Text))

s = smtplib.SMTP()  # 实例化一个SMTP类
s.connect(Server, '25')  # 连接SMTP服务器
s.starttls()  # 开启TLS（安全传输）模式
s.login('18910746927@163.com', 'cisco123')  # 登陆到163邮件服务器
s.sendmail(From, [To], Body)  # 发送邮件
s.quit()  # 退出