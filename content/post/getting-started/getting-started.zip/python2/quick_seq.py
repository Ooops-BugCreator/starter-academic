#coding:utf-8
from PIL import Image, ImageDraw
import base64
import StringIO



def circle():

    ima = Image.frombytes('r', (len(str), ), str)
    # ima = Image.load(str).convert("RGBA")
    size = ima.size
    r2 = min(size[0], size[1])
    if size[0] != size[1]:
        ima = ima.resize((r2, r2), Image.ANTIALIAS)
    circle = Image.new('L', (r2, r2), 0)
    draw = ImageDraw.Draw(circle)
    draw.ellipse((0, 0, r2, r2), fill=255)
    alpha = Image.new('L', (r2, r2), 255)
    alpha.paste(circle, (0, 0))
    ima.putalpha(alpha)
    ima.save("/Users/dickr/Desktop/e.png")


circle()