from time import sleep
from celery import Celery

backend = 'redis://192.168.122.129:6379/2'
broker = 'redis://192.168.122.129:6379/3'

app = Celery('tasks', backend=backend, broker=broker)
# app.conf.CELERY_ACCEPT_CONTENT=['json']
app.conf.task_serializer = 'json'

app.conf.update(
    CELERY_TASK_SERIALIZER='json',
    CELERY_ACCEPT_CONTENT=['json'],
    CELERY_RESULT_SERIALIZER='json',
)


@app.task
def add(x, y):
    sleep(10)
    return x + y