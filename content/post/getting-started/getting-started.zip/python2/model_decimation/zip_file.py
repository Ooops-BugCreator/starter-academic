#coding: utf-8
import re
import os
import zipfile

def zipdir(path):
    for root, dirs, files in os.walk(path):
        print root, dirs, files

        for file in files:
            if re.match(r'.+\.obj$', file):
                file_path = os.path.join(root, file)
                # 压缩文件
                zfile = zipfile.ZipFile(file_path + '.zip', 'w', zipfile.ZIP_DEFLATED)
                zfile.write(file_path)
                zfile.close()
                os.remove(file_path)


            # 删除压缩文件
            # if re.match(r'.+\.zip', file):
            #     os.remove(file_path)


if __name__ == '__main__':
    # zipdir('/Users/dickr/Downloads/mgcmall/PublicWelfareStar/webgl/models/obj/')
    zipdir('../obj/星轨印记手镯')
    # zipdir('model_decimation')
