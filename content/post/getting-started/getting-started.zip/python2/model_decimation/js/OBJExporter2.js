/**
 * @author mrdoob / http://mrdoob.com/
 */

THREE.OBJExporterNew = function () {};

THREE.OBJExporterNew.prototype = {

	constructor: THREE.OBJExporterNew,

	parse: function ( object, uv_flag ) {

		var output = '';

		var indexVertex = 0;
		var indexVertexUvs = 0;
		var indexNormals = 0;

		var vertex = new THREE.Vector3();
		var normal = new THREE.Vector3();
		var uv = new THREE.Vector2();

		var i, j, k, l, m = [];

        var parseMeshNew = function ( mesh ) {

            var nbVertex = 0;
            //var nbNormals = 0;
            //var nbVertexUvs = 0;

            var geometry = mesh.geometry;

            var normalMatrixWorld = new THREE.Matrix3();

            //vertices    faces /a,b,c, normal(x,y,z), materialIndex, vertexNormals(0,1,2(x,y,z))
            if ( geometry instanceof THREE.Geometry ) {

                var vertices = geometry.vertices;
                var faces = geometry.faces;
                // shortcuts

                // name of the mesh object
                output += 'o ' + mesh.name + '\n';

                // name of the mesh material
                if ( mesh.material && mesh.material.name ) {
                    output += 'usemtl ' + mesh.material.name + '\n';
                }

                // vertices

                if( vertices !== undefined ) {

                    for ( i = 0, l = vertices.length; i < l; i ++, nbVertex++ ) {

                        var vertex = vertices[i];

                        // transfrom the vertex to world space
                        //vertex.applyMatrix4( mesh.matrixWorld );

                        // transform the vertex to export format
                        output += 'v ' + vertex.x.toPrecision(7) + ' ' + vertex.y.toPrecision(7) + ' ' + vertex.z.toPrecision(7) + '\n';

                    }

                }


                if (!uv_flag) {

                    // normals

                    var vNormals = [];
                    for ( i = 0, l = faces.length; i < l; i ++ )
                    {
                        var face_t = faces[i];
                        for(j=0; j<3; j++)
                        {
                            var vnn = face_t.vertexNormals[j];
                            var key = vnn.x.toPrecision(7) + '_' + vnn.y.toPrecision(7) + '_' + vnn.z.toPrecision(7);
                            if (undefined === vNormals[key])
                                vNormals[key] = vnn;
                        }
                    }
                    var vnindex = 0;
                    for (k in vNormals)
                    {
                        var vnn = vNormals[k];
                        output += 'vn ' + vnn.x.toPrecision(7) + ' ' + vnn.y.toPrecision(7) + ' ' + vnn.z.toPrecision(7) + '\n';
                        vNormals[k] = vnindex;
                        vnindex ++;
                    }

                    // faces

                    var face = [];
                    for (i = 0, l = faces.length; i < l; i++) {
                        var face_t = faces[i];
                        var vnn0 = face_t.vertexNormals[0];
                        var vnn1 = face_t.vertexNormals[1];
                        var vnn2 = face_t.vertexNormals[2];
                        var key0 = vnn0.x.toPrecision(7) + '_' + vnn0.y.toPrecision(7) + '_' + vnn0.z.toPrecision(7);
                        var key1 = vnn1.x.toPrecision(7) + '_' + vnn1.y.toPrecision(7) + '_' + vnn1.z.toPrecision(7);
                        var key2 = vnn2.x.toPrecision(7) + '_' + vnn2.y.toPrecision(7) + '_' + vnn2.z.toPrecision(7);
                        face[0] = (face_t.a + 1) + '/0/' + (1 + vNormals[key0]);
                        face[1] = (face_t.b + 1) + '/0/' + (1 + vNormals[key1]);
                        face[2] = (face_t.c + 1) + '/0/' + (1 + vNormals[key2]);
                        // transform the face to export format
                        output += 'f ' + face.join(' ') + "\n";
                    }
                }
                else {

                    // uvs
                    // var uvs = [];
                    // var faceVertexUvs = geometry.faceVertexUvs[ 0 ];
                    // var hasVertexUvs = faces.length === faceVertexUvs.length;
                    //
                    // if ( hasVertexUvs ) {
                    //
                    //     for ( var i = 0, l = faceVertexUvs.length; i < l; i ++ ) {
                    //
                    //         var vertexUvs = faceVertexUvs[ i ];
                    //
                    //         for ( var j = 0, jl = vertexUvs.length; j < jl; j ++ ) {
                    //
                    //             var uv = vertexUvs[ j ];
                    //             var key = uv.x.toPrecision(7) + '_' + uv.y.toPrecision(7);
                    //             if (uvs[key] === undefined) {
                    //                 uvs[key] = uv;
                    //             }
                    //         }
                    //
                    //     }
                    //     for (j in uvs) {
                    //         var uv = uvs[j];
                    //         output += 'vt ' + uv.x.toPrecision(7) + ' ' + uv.y.toPrecision(7) + '\n';
                    //
                    //     }
                    //
                    // }

                    var faces = geometry.faces;
                    var faceVertexUvs = geometry.faceVertexUvs[ 0 ];
                    var hasVertexUvs = faces.length === faceVertexUvs.length;

                    if ( hasVertexUvs ) {

                        for ( var i = 0, l = faceVertexUvs.length; i < l; i ++ ) {

                            var vertexUvs = faceVertexUvs[ i ];

                            for ( var j = 0, jl = vertexUvs.length; j < jl; j ++ ) {

                                var uv = vertexUvs[ j ];

                                output += 'vt ' + uv.x.toPrecision(7) + ' ' + uv.y.toPrecision(7) + '\n';
                            }

                        }

                    }


                     // normals

                    var vNormals = [];
                    for ( i = 0, l = faces.length; i < l; i ++ )
                    {
                        var face_t = faces[i];
                        for(j=0; j<3; j++)
                        {
                            var vnn = face_t.vertexNormals[j];
                            var key = vnn.x.toPrecision(7) + '_' + vnn.y.toPrecision(7) + '_' + vnn.z.toPrecision(7);
                            if (undefined === vNormals[key])
                                vNormals[key] = vnn;
                        }
                    }
                    var vnindex = 0;
                    for (k in vNormals)
                    {
                        var vnn = vNormals[k];
                        output += 'vn ' + vnn.x.toPrecision(7) + ' ' + vnn.y.toPrecision(7) + ' ' + vnn.z.toPrecision(7) + '\n';
                        vNormals[k] = vnindex;
                        vnindex ++;
                    }

                    // faces

                    var face = [];
                    for (i = 0, l = faces.length; i < l; i++) {
                        var face_t = faces[i];
                        var vnn0 = face_t.vertexNormals[0];
                        var vnn1 = face_t.vertexNormals[1];
                        var vnn2 = face_t.vertexNormals[2];
                        var key0 = vnn0.x.toPrecision(7) + '_' + vnn0.y.toPrecision(7) + '_' + vnn0.z.toPrecision(7);
                        var key1 = vnn1.x.toPrecision(7) + '_' + vnn1.y.toPrecision(7) + '_' + vnn1.z.toPrecision(7);
                        var key2 = vnn2.x.toPrecision(7) + '_' + vnn2.y.toPrecision(7) + '_' + vnn2.z.toPrecision(7);
                        face[0] = (face_t.a + 1) + '/' + (1 + vNormals[key0]) + '/' + (1 + vNormals[key0]);
                        face[1] = (face_t.b + 1) + '/' + (1 + vNormals[key1]) + '/' + (1 + vNormals[key1]);
                        face[2] = (face_t.c + 1) + '/' + (1 + vNormals[key2]) + '/' + (1 + vNormals[key2]);
                        // transform the face to export format
                        output += 'f ' + face.join(' ') + "\n";
                    }


                    // // normals
                    // for ( var i = 0, l = faces.length; i < l; i ++ ) {
                    //
                    //     var face = faces[i];
                    //     var vertexNormals = face.vertexNormals;
                    //
                    //     if (vertexNormals.length === 3) {
                    //
                    //         for (var j = 0, jl = vertexNormals.length; j < jl; j++) {
                    //
                    //             var normal = vertexNormals[j];
                    //             // normal.applyMatrix3( normalMatrixWorld );
                    //
                    //             output += 'vn ' + normal.x.toPrecision(7) + ' ' + normal.y.toPrecision(7) + ' ' + normal.z.toPrecision(7) + '\n';
                    //
                    //         }
                    //
                    //     }
                    // }

                    // // faces

                    // for (var i = 0, j = 1, l = faces.length; i < l; i++, j += 3) {
                    //
                    //     var face = faces[i];
                    //
                    //     output += 'f ';
                    //     // output += ( indexVertex + face.a + 1 ) + '/' + ( hasVertexUvs ? ( indexVertexUvs + j     ) : '' ) + '/' + ( indexNormals + j     ) + ' ';
                    //     output += ( face.a + 1 ) + '/' + ( hasVertexUvs ? ( j     ) : '' ) + '/' + ( j     ) + ' ';
                    //     // output += ( indexVertex + face.b + 1 ) + '/' + ( hasVertexUvs ? ( indexVertexUvs + j + 1 ) : '' ) + '/' + ( indexNormals + j + 1 ) + ' ';
                    //     output += ( face.b + 1 ) + '/' + ( hasVertexUvs ? ( j + 1 ) : '' ) + '/' + ( j + 1 ) + ' ';
                    //     // output += ( indexVertex + face.c + 1 ) + '/' + ( hasVertexUvs ? ( indexVertexUvs + j + 2 ) : '' ) + '/' + ( indexNormals + j + 2 ) + '\n';
                    //     output += ( face.c + 1 ) + '/' + ( hasVertexUvs ? ( j + 2 ) : '' ) + '/' + ( j + 2 ) + '\n';
                    //
                    // }
                }

            } else {

                console.warn( 'THREE.OBJExporterNew.parseMesh(): geometry type unsupported', geometry );

            }

        };

		object.traverse( function ( child ) {

			if ( child instanceof THREE.Mesh ) {

				parseMeshNew( child );
			}

		} );

		return output;

	}

};
