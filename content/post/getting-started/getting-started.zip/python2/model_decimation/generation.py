#coding: utf-8
import os
import re
from selenium import webdriver
from contextlib import contextmanager
from selenium.webdriver.chrome.options import Options


CHROME_DRIVER_PATH = '/Users/dickr/bin/chromedriver'
GOOGLE_CHROME_PATH = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
LOCAL_HTML_PATH = 'file:///Users/dickr/python2/model_decimation/base.html'
TO_EXEC_JS = """
    var done = arguments[arguments.length-1];
    var camera, scene, renderer;
    var material, mesh;
    
    var file_path = arguments[0];
    var coefficient = arguments[1];
    var uv_flag = arguments[2];
    
    scene = new THREE.Scene();

    camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.x = 150;
    camera.position.y = 50;
    camera.position.z = 150;
    camera.lookAt(scene.position);

    var loader = new THREE.OBJLoader();
    loader.load(file_path, function (object) {

        object.traverse( function ( child ) {
            if (child instanceof THREE.Mesh) {

                var simplify = new THREE.Geometry().fromBufferGeometry(child.geometry);
                simplify.computeFaceNormals();
                simplify.mergeVertices();

                var modifier = new THREE.SimplifyModifier();
                var simplified = modifier.modify(simplify, simplify.vertices.length * coefficient | 0, uv_flag);
                simplified.computeFaceNormals();
                material = new THREE.MeshNormalMaterial();
                mesh = new THREE.Mesh(simplified, material);

                var exporter = new THREE.OBJExporterNew();
                var res = exporter.parse(mesh, uv_flag);
                done(res)
            }
        });

    });

"""



chrome_options = Options()
chrome_options.add_argument('--headless')
chrome_options.add_argument('--allow-file-access-from-files')
chrome_options.binary_location = GOOGLE_CHROME_PATH

@contextmanager
def ensure_shut(instance):
    if isinstance(instance, webdriver.remote.webdriver.WebDriver):
        yield instance
        instance.quit()
    else:
        instance.start()
        yield instance
        instance.stop()


OBJ_PATH = '../obj'

def detail_do(driver, root, file, coefficient, uv_flag=None):
    if re.match(r'.+\.obj$', file):
        if 'jewel' not in file and 'Jewel' not in file:
            file_path = os.path.join(root, file)
            print(file_path)
            res = driver.execute_async_script(TO_EXEC_JS, file_path, coefficient, uv_flag)
            with open(file_path, 'w') as f:
                f.write(res)

def exec_driver():
    with ensure_shut(webdriver.chrome.service.Service(executable_path=CHROME_DRIVER_PATH)) as service:
        with ensure_shut(webdriver.Remote(service.service_url, desired_capabilities=chrome_options.to_capabilities())) as driver:
            driver.get(LOCAL_HTML_PATH)
            for root, dirs, files in os.walk(OBJ_PATH):
                print(root, dirs, files)
                if 'stone' not in root and 'starplate' not in root:

                    # bangle/ear/ring全部文件轻度优化（不包含jewel）
                    if 'bangle' in root or 'ear' in root or 'ring' in root:
                        for file in files:
                            detail_do(driver, root, file, 0.1)

                    # necklace 部分文件轻度优化（不包含jewel）
                    if 'necklace' in root:
                        for file in files:
                            if file not in ['new_round_001.obj', 'new_round_J_001.obj']:
                                detail_do(driver, root, file, 0.1)

                    # showall 部分文件轻度优化（不包含jewel）
                    elif 'showall' in root:
                        for file in files:
                            if file in ['Exhibit_Bangle_001.obj', 'Exhibit_Ring_001.obj', 'Exhibit_Earring_001.obj']:
                                detail_do(driver, root, file, 0.1)

                    # chain高度优化（不包含jewel）
                    elif 'chain' in root:
                        for file in files:
                            detail_do(driver, root, file, 0.7)

                    # starplate轻度优化（带jewel）, 其余中度优化
                    # elif 'starplate' in root:
                    #     for file in files:
                    #         if 'jewel' in file:
                    #             detail_do(driver, root, file, 0.5, 1)
                    #         else:
                    #             detail_do(driver, root, file, 0.5)

                    # 其余中度优化
                    else:
                        for file in files:
                            detail_do(driver, root, file, 0.7)


if __name__ == '__main__':
    exec_driver()

