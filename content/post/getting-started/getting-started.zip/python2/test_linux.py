from contextlib import contextmanager
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

service = webdriver.chrome.service.Service('./chromedriver')
service.start()
chrome_options = Options()
chrome_options.add_argument("--headless")
chrome_options.add_argument("--allow-file-access-from-files")
chrome_options.binary_location = '/usr/bin/google-chrome'
driver = webdriver.Remote(service.service_url, desired_capabilities=chrome_options.to_capabilities())



@contextmanager
def quitting(quitter):
    try:
        yield quitter
    finally:
        quitter.quit()

with quitting(webdriver.Remote(service.service_url, desired_capabilities=chrome_options.to_capabilities())) as driver:


    driver.get('file:///root/python/mgcmall/PublicWelfareStar/webgl/test.html')
    res = driver.execute_async_script("""
        var done = arguments[0];
        function datashow() {
            done(showing.GetFileData()) 
        }
        var container = document.getElementById('webgl');
        var showing = new SHOWING(container);
        var paramlist = new SHOWING.ParamList();
        showing.Reload(paramlist, datashow);
    """)

# driver.quit()

# print res
with open('./t.stl', 'w') as f:
    f.write(res)



