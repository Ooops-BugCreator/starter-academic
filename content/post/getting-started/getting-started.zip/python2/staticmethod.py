#!/usr/bin/env python

def wrapper(func):
    def inner_wrapper(*args, **kwargs):
        print 'start'
        func(*args, **kwargs)
        print 'end'
    return inner_wrapper

class Test(object):
    def __init__(self):
        self._th = 'test'

    def func1(self):
        print 'func1'
        Test.func2()

    @staticmethod
    @wrapper
    def func2():
        print 'func2'

    @classmethod
    def func3(cls, arg):
        print cls, arg

t = Test()
#t.func1()
t.func3(5)
