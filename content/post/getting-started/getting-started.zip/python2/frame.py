#coding:utf-8

"""
手机验证码接口
"""
class Vcode(object):

    @staticmethod
    def send_sms(business_id, phone_number, sign_name, template_code, template_param=None):
        """
        阿里云短信接口
        :param business_id:
        :param phone_number:
        :param sign_name:
        :param template_code:
        :param template_param:
        :return:
        """
        pass

    @staticmethod
    @is_phone_num_valid # 检测手机号是否合法
    def get_vcode(request, phone_num=None, jsonpCallback=None, *args, **kwargs):
        """
        返回客户端验证码，调用Vcode.send_sms()
        :param request:
        :param phone_num:
        :param jsonpCallback:
        :param args:
        :param kwargs:
        :return:
        """


"""
登陆注册接口
"""

class UserLogin(TemplateView):
    @staticmethod
    def password_check(password):
        """
        检测密码强度
        """
        pass

    @staticmethod
    @is_phone_num_valid # 检测手机号是否合法
    def check_data(request, phone_num=None, jsonpCallback=None, login_flag=False, register_flag=False):
        """
        认证用户数据并注册／登陆，调用UserLogin.password_check()
        :param request:
        :param phone_num:
        :param jsonpCallback:
        :param login_flag:
        :param register_flag:
        :return:
        """
        pass

    def get(self, request, *args, **kwargs):
        """
        如果提交字段都不为空，调用UserLogin.check_data();
        否则返回提示信息
        :param request:
        :param args:
        :param kwargs:
        :return:
        """
        pass

class UserRegister(TemplateView):

    def get(self, request, *args, **kwargs):
        """
        首先判断两次密码是否相同，再判断提交字段都不为空，
        调用UserLogin.check_data();
        否则返回提示信息
        :param request:
        :param args:
        :param kwargs:
        :return:
        """

"""
首饰盒接口
"""
class JewelryBoxDisplay(TemplateView):

    def get(self, request, *args, **kwargs):
        """
        展示用户加入首饰盒的相关商品信息
        """
        pass

class JewelryBoxCollectionOrNot(TemplateView):
    def get(self, request, *args, **kwargs):
        """
        加入／取消收藏
        :return:
        """
        pass

"""
购物车接口
"""
class ShoppingCart(TemplateView):
    def get(self, request, *args, **kwargs):
        """
        加入／取消购物车
        :return:
        """
        pass
