import time
import random
import multiprocessing.dummy as multiprocessing
from selenium import webdriver
from contextlib import contextmanager
from selenium.webdriver.chrome.options import Options
t1 = time.time()

chrome_options = Options()
# chrome_options.add_argument('--headless')
chrome_options.add_argument('--allow-file-access-from-files')
# chrome_options.add_argument('--proxy-server=%s' % '0.0.0.0:9090')
# chrome_options.binary_location = '/Applications/Google Chrome Canary.app/Contents/MacOS/Google Chrome Canary'
chrome_options.binary_location = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'



@contextmanager
def quitting(quitter):
    try:
        yield quitter
    finally:
        quitter.quit()


script = """
        var done = arguments[arguments.length-1];
        
        function execs() {
            //var array = [showing.GetFileData(), showing.GetVolume()];
            return {data: showing.GetFileData(), volume: showing.GetVolume()}
        }
        
        function datashow() {
            done({data: showing.GetFileData(), volume: showing.GetVolume()}) 
        }
        var container = document.getElementById('webgl');
        var showing = new SHOWING(container);
        var paramlist = new SHOWING.ParamList();
        
        for (i in arguments[0]) {
        paramlist[i] = arguments[0][i];
        }
        
        showing.Reload(paramlist, datashow);
        alert(arguments[1]);
"""

def test():
    res = driver.execute_async_script(script, {"jewelID":"neck","text":"[14]stack[16]","linkstyle":"7","font":"1","color":"1","stone":"1","bodycolor":"1","textcolor":"1","embedtype":"1","chaincolor":"1","chainstyle":"1","tailstyle":"1","textinterval":5}, 5)
    # num = random.randint(0, 100)
    # with open(str(num) + '.stl', 'w') as f:
    #     f.write(res['data'])
    print(res['volume'])

# with quitting(webdriver.Remote(command_executor='http://localhost:9515', desired_capabilities=chrome_options.to_capabilities())) as driver:

driver = webdriver.Remote(command_executor='http://localhost:9515', desired_capabilities=chrome_options.to_capabilities())
driver.get('file:///Users/dickr/Downloads/mgcmall/PublicWelfareStar/webgl/test.html')
# res = []
# pool = multiprocessing.Pool(4)
# # for _ in range(1):
# res.append(pool.apply_async(test, args=()))
# pool.close()
# pool.join()

test()

# print(res)
# for i in res:
#     num = random.randint(0, 100)
#     with open(str(num) + '.stl', 'w') as f:
#         ires = i.get()
#         print ires[:100]
#         f.write(ires)


t2 = time.time()
print t2 - t1


